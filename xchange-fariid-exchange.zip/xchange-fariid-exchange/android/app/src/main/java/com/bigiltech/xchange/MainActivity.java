package com.bigiltech.sarif;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.telecom.PhoneAccountHandle;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import android.util.Log;
import android.widget.Toast;

import java.util.List;
import java.util.concurrent.CompletableFuture;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodCall;
import io.flutter.plugin.common.MethodChannel;
import io.flutter.embedding.android.FlutterActivity;
import pub.devrel.easypermissions.AppSettingsDialog;
import pub.devrel.easypermissions.EasyPermissions;

public class MainActivity extends FlutterActivity implements EasyPermissions.PermissionCallbacks {
    private static final String TAG = "MainActivity";

    private static final String CHANNEL = "com.bigiltech.ussd_service/plugin_channel";
    private TelephonyManager.UssdResponseCallback ussdResponseCallback;
    private Handler handler;
    private TelephonyManager telephonyManager;
    private MethodChannel.Result result = null;

    private String[] wantedPerm = { Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE };

    // Slot names.
    // Different phones use different slot names.
    private final static String simSlotName[] = {
        "extra_asus_dial_use_dualsim",
        "com.android.phone.extra.slot",
        "slot",
        "simslot",
        "sim_slot",
        "subscription",
        "Subscription",
        "phone",
        "com.android.phone.DialingMode",
        "simSlot",
        "slot_id",
        "simId",
        "simnum",
        "phone_type",
        "slotId",
        "slotIdx",
        "simSlotIndex",
        "Android.telecom.extra.PHONE_ACCOUNT_HANDLE"
    };

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), CHANNEL)
                .setMethodCallHandler((call, result) -> {
                    Log.d(TAG, "Handle the method: " + call.method);
                    if (call.method.equals("makeRequest")) {
                        try {
                            // Get method parameters.
                            final UssdRequestParams mParams = new UssdRequestParams(call);

                            // Handle request.
                            this.result = result;
                            String resp = makeRequest(mParams);

                            // Fail immediately.
                            if( resp != null) {
                                result.success(resp);
                            }
                        } catch (RequestParamsException e) {
                            result.error(RequestParamsException.type, e.message, null);
                        } catch (RequestExecutionException e) {
                            result.error(RequestParamsException.type, e.message, null);
                        } catch (Exception e) {
                            result.error("unknown_exception", e.getMessage(), null);
                        }
                    } else {
                        result.notImplemented();
                    }
                });

        // Configure callback.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Callback.
            ussdResponseCallback = new TelephonyManager.UssdResponseCallback() {
                @Override
                public void onReceiveUssdResponse(TelephonyManager telephonyManager, String request, CharSequence response) {
                    super.onReceiveUssdResponse(telephonyManager, request, response);
                    Toast.makeText(MainActivity.this, "onReceiveUssdResponse: " + response, Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onReceiveUssdResponseFailed(TelephonyManager telephonyManager, String request, int failureCode) {
                    super.onReceiveUssdResponseFailed(telephonyManager, request, failureCode);
                    Toast.makeText(MainActivity.this, "onReceiveUssdResponseFailed: " + failureCode, Toast.LENGTH_SHORT).show();
                }
            };

            // Handler.
            handler = new Handler(Looper.getMainLooper()) {
                @Override
                public void handleMessage(@NonNull Message msg) {
                    Log.d(TAG, "handleMessage: " + msg);
                    super.handleMessage(msg); //no need to change anything here
                }
            };

            // Get telephony manager.
            telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        }
    }

    /**
     * Handles request from Flutter side.
     *
     * @param ussdRequestParams
     * @return
     * @throws RequestExecutionException
     */
    private String makeRequest(final UssdRequestParams ussdRequestParams) throws RequestExecutionException {

        // Check for needed permissions, make request if needed.
        if (!EasyPermissions.hasPermissions(this, wantedPerm)) {
            EasyPermissions.requestPermissions(this, "This app needs access to send and receive SMS.", 125, wantedPerm);
        } else {
            // Needed permission is given.
            Log.d( TAG, "#Using slotId: " + ussdRequestParams.slotId + " and subscriptionId: " + ussdRequestParams.subscriptionId );

            // Make unstructured supplementary service data request, based on the OS version.
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
                // Older than Android 6 (Marshmallow).

                Log.d( TAG, "#### Older than Android 6." );

                // Construct intent.
                Intent intent = new Intent(Intent.ACTION_CALL, codeToCallableUri(ussdRequestParams.code));
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("com.android.phone.force.slot", true);
                intent.putExtra("Cdma_Supp", true);

                // Add all possible slot names.
                for( String s : simSlotName ) {
                    intent.putExtra(s, ussdRequestParams.slotId);
                }

                // Start activity.
                startActivity(intent);
            } else {
                // Newer than Android 6.

                Log.d( TAG, "#### Newer than Android 6." );

                // Get TelecomManager.
                TelecomManager telecomManager = (TelecomManager) getSystemService( TELECOM_SERVICE );
                Uri uri = Uri.fromParts("tel", ussdRequestParams.code.trim(), null);
                if (checkPermission("android.permission.READ_PHONE_STATE", android.os.Process.myPid(), android.os.Process.myUid() ) == PackageManager.PERMISSION_GRANTED) {
                    List<PhoneAccountHandle> phnacchandle = telecomManager.getCallCapablePhoneAccounts();
                    Bundle extras = new Bundle();
                    if (phnacchandle.size() > 1)
                        extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, phnacchandle.get(ussdRequestParams.slotId));
                    else
                        extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, phnacchandle.get(0));
                    telecomManager.placeCall(uri, extras);
                } else {
                    return "Permission denied. Allow permission from phone settings";
                }
            }
        }
        return "";
    }

    @TargetApi(Build.VERSION_CODES.O)
    private String makeUssdRequest(UssdRequestParams ussdRequestParams) {
        if (checkSelfPermission("android.permission.CALL_PHONE") == PackageManager.PERMISSION_GRANTED) {
            telephonyManager.createForSubscriptionId(ussdRequestParams.subscriptionId).sendUssdRequest(ussdRequestParams.code, ussdResponseCallback, handler);
        } else {
            return "Permission denied. Allow permission from phone settings";
        }
        return null;
    }

    /**
     * Private method that converts a code into callable url.
     * @param code
     * @return
     */
    private Uri codeToCallableUri(String code) {

        String uriString = "";

        if (!code.startsWith("tel:"))
            uriString += "tel:";

        for (char c : code.toCharArray()) {

            if (c == '#')
                uriString += Uri.encode("#");
            else
                uriString += c;
        }

        return Uri.parse(uriString);
    }


    @Override
    public void onPermissionsGranted(int requestCode, @NonNull List<String> perms) {

    }

    @Override
    public void onPermissionsDenied(int requestCode, @NonNull List<String> perms) {
        if (EasyPermissions.somePermissionPermanentlyDenied(this, perms)) {
            new AppSettingsDialog.Builder(this).setTitle("Permissions Required").setPositiveButton("Settings")
                    .setNegativeButton("Cancel").setRequestCode(126).build().show();
        }
    }

    private static class RequestExecutionException extends Exception {

        static String type = "ussd_plugin_ussd_execution_failure";
        String message;

        RequestExecutionException(String message) {
            this.message = message;
        }
    }

    private static class RequestParamsException extends Exception {

        static String type = "ussd_plugin_incorrect__parameters";
        String message;

        RequestParamsException(String message) {
            this.message = message;
        }
    }

    private static class UssdRequestParams {

        int slotId;
        int subscriptionId = -1;
        String code;

        UssdRequestParams(@NonNull MethodCall call) throws RequestParamsException {
            Integer slotIdInteger = call.argument("slotId");
            if (slotIdInteger == null) {
                throw new RequestParamsException("Incorrect parameter type: `slotId` must be an int");
            }
            slotId = slotIdInteger;
            if (slotId < 0) {
                throw new RequestParamsException("Incorrect parameter value: `slotId` must be >= 0");
            }

            // Get subscription id.
            Integer subsIdInteger = call.argument("subscriptionId");
            if (subsIdInteger != null) {
                subscriptionId = subsIdInteger;
            }

            code = call.argument("code");
            if (code == null) {
                throw new RequestParamsException("Incorrect parameter type: `code` must be a String");
            }
            if (code.length() == 0) {
                throw new RequestParamsException("Incorrect parameter value: `code` must not be an empty string");
            }
        }
    }
}
