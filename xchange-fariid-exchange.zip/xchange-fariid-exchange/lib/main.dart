import 'package:flutter/material.dart';
import 'dart:async';
import 'package:flutter/services.dart';
// sim info
import 'package:sim_data/sim_data.dart';
import 'package:permission_handler/permission_handler.dart';

// USSD Service
import 'package:FARIIDEXCHANGE/ussd_service.dart';

// URL Launcher.
import 'package:url_launcher/url_launcher.dart';

// screens
import './screens/contact_screen.dart';
// widgets
import './widgets/zaad_screen.dart';
import './widgets/edahab_screen.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
      systemNavigationBarColor: Colors.green[800], // navigation bar color
      statusBarColor: Colors.green[800], // status bar color
    ));
    return MaterialApp(
      title: 'Suldan Farid Exchange',
      theme: ThemeData(
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
//  state

  String amount = '';
  String currencyType = 'dollar';
  String currencySing = "\$ ";
  String _firstSim;

  // sim service
  // Platform messages are asynchronous, so we initialize in an async method.
  Future<void> getSimInfo() async {
    SimData simData;
    try {
      var status = await Permission.phone.status;
      if (!status.isGranted) {
        bool isGranted = await Permission.phone.request().isGranted;
        if (!isGranted) return;
      }
      simData = await SimDataPlugin.getSimData();
      setState(() {
        _firstSim = simData.cards.first.carrierName;
      });
      print(_firstSim);
    } catch (e) {
      debugPrint(e.toString());
      setState(() {
        _firstSim = null;
      });
    }
  }

  void updateAmount(newAmount) {
    setState(() {
      amount = newAmount;
    });
  }

  void updateCurrencyType(type) {
    setState(() {
      currencyType = type;
    });
  }

  void updateCurrencySign(sign) {
    setState(() {
      currencySing = sign;
    });
  }

  // url launcher
  launchURL(String url) async {
    try {
      await launch(url);
    } catch (e) {
      print(e);
    }
  }

  void makeMyRequest(String code, int slotId, int subscriptionId) async {
    // int slotId = 0; // sim card subscription ID
    try {
      String ussdResponseMessage = await UssdService.makeRequest(
        code,
        slotId,
        subscriptionId,
        Duration(seconds: 10), // timeout (optional) - default is 10 seconds
      );
      print("succes! message: $ussdResponseMessage");
    } catch (e) {
      debugPrint("error! code: ${e.code} - message: ${e.message}");
    }
  }

  @override
  void initState() {
    super.initState();
    getSimInfo();
  }

//  app Build

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: DefaultTabController(
        length: 2,
        child: Container(
          margin: EdgeInsets.only(top: 20.0),
          child: Scaffold(
            backgroundColor: Colors.green[800],
            resizeToAvoidBottomInset: false,
            appBar: AppBar(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.only(
                    topRight: Radius.circular(10.0),
                    topLeft: Radius.circular((10.0))),
              ),
              backgroundColor: Colors.green[800],
              title: Padding(
                padding: const EdgeInsets.only(bottom: 16.0),
                child: Text(
                  'Suldan Farid Exchange',
                  style: TextStyle(color: Colors.white, fontSize: 30.0),
                ),
              ),
              centerTitle: true,
              bottom: TabBar(
                indicatorColor: Colors.white70,
                indicatorWeight: 3.0,
                labelStyle:
                    TextStyle(fontWeight: FontWeight.bold, fontSize: 16.0),
                onTap: (index) {
                  print(index);
                },
                tabs: [
                  Tab(
                    icon: ClipRRect(
                      borderRadius: BorderRadius.circular(4.0),
                      child: Image.asset(
                        'assets/images/zaad.jpg',
                        width: 50.0,
                        height: 40.0,
                        fit: BoxFit.fill,
                      ),
                    ),
                    text: "Zaad",
                  ),
                  Tab(
                    icon: ClipRRect(
                      borderRadius: BorderRadius.circular(4.0),
                      child: Image.asset(
                        'assets/images/edahab.png',
                        width: 50.0,
                        height: 40.0,
                        fit: BoxFit.fill,
                      ),
                    ),
                    text: "eDahab",
                  ),
                ],
              ),
            ),
            body: Container(
              color: Colors.green[800],
              child: Container(
                child: GestureDetector(
                  onTap: () {
                    FocusScope.of(context).requestFocus(new FocusNode());
                  },
                  child: TabBarView(
                    children: [
                      ZaadScreen(
                          makeMyRequest,
                          updateAmount,
                          amount,
                          currencyType,
                          updateCurrencyType,
                          currencySing,
                          updateCurrencySign,
                          launchURL,
                          _firstSim),
                      EdahabScreen(
                          makeMyRequest,
                          updateAmount,
                          amount,
                          currencyType,
                          updateCurrencyType,
                          currencySing,
                          updateCurrencySign,
                          launchURL,
                          _firstSim),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
//      bottomNavigationBar: BottomNav(),

      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.green[800],
        onPressed: () {
          showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              builder: (context) {
                return FractionallySizedBox(
                  heightFactor: 0.60,
                  child: ContactScreen(launchURL),
                );
              });
        },
        child: Icon(Icons.menu),
      ),
    );
  }
}