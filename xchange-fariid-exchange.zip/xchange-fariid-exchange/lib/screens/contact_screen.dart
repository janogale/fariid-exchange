import 'package:flutter/material.dart';
import 'package:share/share.dart';

// ignore: camel_case_types
class ContactScreen extends StatelessWidget {
  final Function launchURL;
  ContactScreen(this.launchURL);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.pop(context);
      },
      child: Container(
        color: Colors.grey[600],
        child: Container(
            padding: EdgeInsets.only(top: 15.0),
            decoration: BoxDecoration(
                color: Colors.green[700],
                shape: BoxShape.rectangle,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(25.0),
                    topRight: Radius.circular(25.0))),
            child: Padding(
              padding: EdgeInsets.only(
                  top: 10.0, bottom: 10.0, right: 50.0, left: 50.0),
              child: ListView(
                children: <Widget>[
                  Card(
                    child: ListTile(
                      onTap: () {
                        Share.share(
                            "https://play.google.com/store/apps/details?id=com.bigiltech.farid",
                            subject: "Suldan Farid Money Exchange");
                      },
                      title: Text('Share App with friend'),
                      trailing: CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: 15,
                        backgroundImage: AssetImage('assets/images/share.png'),
                      ),
                    ),
                  ),
                                 Card(
                      child: ListTile(
                    onTap: () {
                      launchURL("tel:0633078100");
                    },
                    title: Text('Call us    (Telesom)'),
                    trailing: CircleAvatar(
                      backgroundColor: Colors.white,
                      radius: 15,
                      backgroundImage: AssetImage('assets/images/call.png'),
                    ),
                  )),
                
                  Card(
                    child: ListTile(
                      onTap: () {
                        launchURL("whatsapp://send?phone=252633078100");
                      },
                      title: Text('Chat with us on WhatsApp'),
                      trailing: CircleAvatar(
                        backgroundColor: Colors.white,
                        radius: 15,
                        backgroundImage:
                            AssetImage('assets/images/whatsapp.png'),
                      ),
                    ),
                  ),
                      SizedBox(height: 30),

                  ListTile(
                   
                    title: Text(
                      'Developed By Bigil Technologies',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white70),
                    ),
                   
                  ),
                  FlatButton(
                    onPressed: () {
                      launchURL('https://bigiltech.com/');
                    },
                    child: Text(
                      'bigiltech.com',
                      style: TextStyle(
                        color: Colors.indigo[900],
                      ),
                    ),
                  ),
                ],
              ),
            )),
      ),
    );
  }
}
