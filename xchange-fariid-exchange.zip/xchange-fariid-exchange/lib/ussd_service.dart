import 'dart:async';

import 'package:flutter/services.dart';

///
/// Flutter class that makes a call to the platform specific side to trigger a USSD code.
/// Currently supports only Android.
///
class UssdService {
  static const MethodChannel _channel =
      MethodChannel("com.bigiltech.ussd_service/plugin_channel");

  /// Make a platform-specific request.
  static Future<String> makeRequest(
    String code,
    int slotId,
    int subscriptionId, [
    Duration timeout = const Duration(seconds: 10),
  ]) async {
    final String response = await _channel
        .invokeMethod(
          "makeRequest",
          { "code": code, "slotId": slotId, "subscriptionId": subscriptionId },
        )
        .timeout(timeout)
        .catchError((e) {
          // TODO: Move timeout handling to Android side once Java 9 is used
          // and `CompletableFuture.timeout` is available
          if (e is TimeoutException) {
            throw PlatformException(
                code: "ussd_plugin_ussd_execution_timeout", message: e.message);
          }
          throw e;
        });
    return response;
  }
}
