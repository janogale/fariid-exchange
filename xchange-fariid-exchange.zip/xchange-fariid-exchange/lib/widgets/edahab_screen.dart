import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class EdahabScreen extends StatelessWidget {
  final Function makeMyRequest;
  final Function updateAmount;
  final String amount;
  final String currencyType;
  final Function updateCurrencyType;
  final String currencySign;
  final String _firstSim;
  final Function updateCurrencySign;
  final Function launchURL;

  EdahabScreen(
      this.makeMyRequest,
      this.updateAmount,
      this.amount,
      this.currencyType,
      this.updateCurrencyType,
      this.currencySign,
      this.updateCurrencySign,
      this.launchURL,
      this._firstSim);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: new BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.all(Radius.circular(35.0))),
      margin: EdgeInsets.only(bottom: 10.0),
      child: Column(
        children: <Widget>[
          SizedBox(
            height: 25.0,
          ),
          Padding(
              padding: EdgeInsets.symmetric(horizontal: 65.0, vertical: 0.0),
              child: TextFormField(
                  style: TextStyle(fontSize: 20.0, fontWeight: FontWeight.bold),
                  inputFormatters: [
                    LengthLimitingTextInputFormatter(10),
                  ],
                  onChanged: (value) {
                    updateAmount(value);
                  },
                  validator: (value) {
                    if (value.isEmpty) {
                      return 'Please enter Amount';
                    }
                    return null;
                  },
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    labelText: 'Enter Money',
                    prefix: Text(currencySign),
                    suffixIcon: Icon(Icons.dialpad),
                  ),
                  keyboardType:
                      TextInputType.numberWithOptions(decimal: true))),
          SizedBox(
            height: 20.0,
          ),
          //##############################//
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 30.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                RaisedButton.icon(
                    color: currencyType == 'dollar'
                        ? Colors.yellow[700]
                        : Colors.grey[300],
                    padding: EdgeInsets.all(10.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    onPressed: () {
                      updateCurrencyType('dollar');
                      updateCurrencySign('\$ ');
                    },
                    icon: Image.asset(
                      'assets/images/dollar2.jpg',
                      width: 40,
                      height: 40,
                    ),
                    label: Text(
                      "Dollar",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 10),
                    )),
                RaisedButton.icon(
                    color: currencyType == 'shilling'
                        ? Colors.yellow[700]
                        : Colors.grey[300],
                    padding: EdgeInsets.all(10.0),
                    onPressed: () {
                      updateCurrencyType('shilling');
                      updateCurrencySign('SL. ');
                    },
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    icon: Image.asset(
                      'assets/images/shilling.jpg',
                      width: 40,
                      height: 40,
                    ),
                    label: Text(
                      "Shilling",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 10),
                    )),
              ],
            ),
          ),
          SizedBox(
            height: 30.0,
          ),
          // Sarifo Button //
          RaisedButton(
            color: Colors.white,
            textColor: Colors.yellow[700],
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5.0),
                side: BorderSide(color: Colors.yellow[700])),
            padding: EdgeInsets.fromLTRB(45.0, 10.0, 45.0, 10.0),
            onPressed: () {
              //   check active sim.
              var slot = 1;
              var simId = 5;

              if (_firstSim == "SOMTEL") {
                slot = 0;
                simId = 4;
              }

              var formatedAmount = amount;

              if (formatedAmount == '' || amount == '') {
                return;
              }

              // change . to start to allow fraction exchange
              if (amount.contains(".")) {
                formatedAmount =
                    formatedAmount.replaceFirst(new RegExp(r'\.'), '*');
              }

              if (currencyType == 'dollar') {
                makeMyRequest("*109*659883000*$formatedAmount#", slot, simId);
              } else if (currencyType == 'shilling') {
                makeMyRequest("*119*659883000*$amount#", slot, simId);
              }

              // clear data
              updateAmount("");
            },
            child: const Text('Sarifo',
                style: TextStyle(
                    fontSize: 30.0,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 2.0)),
          ),
          SizedBox(
            height: 25.0,
          ),

          Card(
            child: ListTile(
              leading: Image.asset(
                'assets/images/icon.png',
              ),
              title: Text(
                'Mahadnaq',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              subtitle: Text(
                  'Macmiil, waad ku Mahadsantahay isticmaalka Adeega Sarifka ee Suldan Farid Money Exchange.'),
              isThreeLine: true,
            ),
          ),
          ClipRRect(
            borderRadius: BorderRadius.circular(8.0),
            child: Image.asset(
              'assets/images/somtel.jpg',
              width: 110.0,
              height: 110.0,
              fit: BoxFit.fill,
            ),
          ),
        ],
      ),
    );
  }
}
