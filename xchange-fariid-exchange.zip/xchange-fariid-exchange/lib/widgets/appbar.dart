import 'package:flutter/material.dart';

Widget appBarWidget() {
  return AppBar(
    centerTitle: true,
    title: Text(
      'Suldan Farid Exchange',
      overflow: TextOverflow.ellipsis,
      style: TextStyle(color: Colors.white, fontSize: 20.0),
    ),
    elevation: 0,
    backgroundColor: Colors.green[900],
    leading: IconButton(
        color: Colors.black,
        icon: CircleAvatar(
          backgroundColor: Colors.white,
          backgroundImage: AssetImage('assets/images/telesom.png'),
        ),
        onPressed: () {}),
    actions: <Widget>[
      IconButton(
        icon: CircleAvatar(
          backgroundColor: Colors.white,
          radius: 17,
          backgroundImage: AssetImage('assets/images/somtel.png'),
        ),
        onPressed: () {},
      )
    ],
  );
}
