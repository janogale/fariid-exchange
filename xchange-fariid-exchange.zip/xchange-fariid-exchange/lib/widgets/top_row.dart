import 'package:flutter/material.dart';

topRow() {
  return Container(
    padding: const EdgeInsets.only(top: 20.0),
    color: Colors.white,
    child: Container(
        child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.center,
      children: <Widget>[
        Text(
          'CABDI XAAJIi',
          style: TextStyle(
              fontSize: 30.0, fontWeight: FontWeight.w900, color: Colors.white),
        ),
        SizedBox(
          height: 10.0,
        ),
        Text(
          'Money Exchage',
          style: TextStyle(
              fontSize: 20.0, fontWeight: FontWeight.w900, color: Colors.white),
        ),
      ],
    )),
  );
}
